<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 11/08/2018
 * Time: 20:22
 */

//

// use this instagram access token generator http://instagram.pixelunion.net/
$access_token="286963770.1677ed0.7a6caef42ae145c0bafe6d537918d29b";
$photo_count=8;

$json_link="https://api.instagram.com/v1/users/self/media/recent/?";
$json_link.="access_token={$access_token}&count={$photo_count}";

$json = file_get_contents($json_link);
$obj = json_decode($json, true, 512, JSON_BIGINT_AS_STRING);

foreach ($obj['data'] as $post) {

    $pic_text=substr($post['caption']['text'],0,90). "...";
    $pic_link=$post['link'];
    $pic_like_count=$post['likes']['count'];
    $pic_comment_count=$post['comments']['count'];
    $pic_src=str_replace("http://", "https://", $post['images']['standard_resolution']['url']);
    $pic_created_time=date("F j, Y", $post['caption']['created_time']);
    $pic_created_time=date("F j, Y", strtotime($pic_created_time . " +1 days"));

    echo <<<HTML
    <div class="col-md-3 col-sm-6 item_box">
                        <div class="instagram animate-box">
                            <a href='{$pic_link}'><img class='photo-thumb' src='{$pic_src}' alt='{$pic_text}'></a>
                            <h3>{$pic_text}</h3>
                            <span class='insta_date'><a href='{$pic_link}' target='_blank'>{$pic_created_time}</a></span>
                        </div>
    </div>
HTML;

}
?>

<style>
    .item_box{
        height:500px;
    }
    .photo-thumb{
        width:100%;
        height:auto;
        float:left;
        border: thin solid #d1d1d1;
        margin:0 1em .5em 0;
        float:left;
        -webkit-border-radius: 20px;
        -moz-border-radius: 20px;
        border-radius: 20px;
    }
</style>
