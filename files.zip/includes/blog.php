<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 29/04/2018
 * Time: 19:32
 */?>




<div id="fh5co-blog-section">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="col-md-12">
                    <div class="heading-section animate-box">
                        <h2>Recent from Blog</h2>
                    </div>
                </div>
                <div class="col-md-12 col-md-offset-0">
                    <div class="fh5co-blog animate-box">
                        <div class="inner-post">
                            <a href="#"><img class="img-responsive" src="images/blog-1.jpg" alt=""></a>
                        </div>
                        <div class="desc">
                            <h3><a href=""#>Starting new session of body building this summer</a></h3>
                            <span class="posted_by">Posted by: Admin</span>
                            <span class="comment"><a href="">21<i class="icon-bubble22"></i></a></span>
                            <p>Far far away, behind the word mountains</p>
                            <a href="#" class="btn btn-default">Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-md-offset-0">
                    <div class="fh5co-blog animate-box">
                        <div class="inner-post">
                            <a href="#"><img class="img-responsive" src="images/blog-1.jpg" alt=""></a>
                        </div>
                        <div class="desc">
                            <h3><a href=""#>Starting new session of body building this summer</a></h3>
                            <span class="posted_by">Posted by: Admin</span>
                            <span class="comment"><a href="">21<i class="icon-bubble22"></i></a></span>
                            <p>Far far away, behind the word mountains</p>
                            <a href="#" class="btn btn-default">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="col-md-12">
                    <div class="heading-section animate-box">
                        <h2>Upcoming Events</h2>
                    </div>
                </div>
                <div class="col-md-12 col-md-offset-0">
                    <div class="fh5co-blog animate-box">
                        <div class="meta-date text-center">
                            <p><span class="date">14</span><span>June</span><span>2016</span></p>
                        </div>
                        <div class="desc desc2">
                            <h3><a href=""#>Starting new session of body building this summer</a></h3>
                            <span class="posted_by">Posted by: Admin</span>
                            <span class="comment"><a href="">21<i class="icon-bubble22"></i></a></span>
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia</p>
                            <a href="#" class="btn btn-default">Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-md-offset-0">
                    <div class="fh5co-blog animate-box">
                        <div class="meta-date text-center">
                            <p><span class="date">13</span><span>June</span><span>2016</span></p>
                        </div>
                        <div class="desc desc2">
                            <h3><a href=""#>Starting new session of body building this summer</a></h3>
                            <span class="posted_by">Posted by: Admin</span>
                            <span class="comment"><a href="">21<i class="icon-bubble22"></i></a></span>
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia</p>
                            <a href="#" class="btn btn-default">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
