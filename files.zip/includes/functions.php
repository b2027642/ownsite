<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 28/04/2018
 * Time: 23:45
 */

include_once("connection.php");


function get_config(){

    global  $dbh;

    $sql = $dbh->query("SELECT * FROM config ");
    $sql->execute();

    $data = $sql->fetch(PDO::FETCH_OBJ);

    return $data;

}


function get_seo_details(){

    //get page_id
    $get_url = ( $_SERVER['REQUEST_URI'] );

    $get_url = preg_replace( '/\?.*/', '', $get_url );

    $explode_url = explode( "/", $get_url );

//Check to make sure the array is not empty (Seems to have time when the array can return empty Args and we need count of this to gewt thsi to work)
    foreach ($explode_url AS $k => $e) {
        if ((int) $k > 0 && empty( $e )) {
            unset( $explode_url[$k] );
        }
    }



    $url = $explode_url[2];

    global $dbh;

    $sql = $dbh->prepare("SELECT * from pages where url=:_url");
    $sql->bindParam(":_url",$url, PDO::PARAM_STR);
    $sql->execute();

    $data = $sql->fetch(PDO::FETCH_OBJ);

    return $data;

}



?>