<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 29/04/2018
 * Time: 18:58
 */

include_once("connection.php");


global $dbh;

$sql = $dbh->query("SELECT * FROM programs");
$sql->execute();

while($row = $sql->fetch(PDO::FETCH_OBJ)){

    echo <<<HTML

    <div class="col-md-4 col-sm-6">
                        <div class="program animate-box">
                            <img src="images/$row->image" alt="Cycling">
                            <h3>{$row->name}</h3>
                            <p>{$row->content}</p>
                            <span><a href="contact" class="btn btn-default">Join Now</a></span>
                        </div>
    </div>


HTML;



}





?>