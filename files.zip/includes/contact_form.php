<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 29/04/2018
 * Time: 00:40
 */


ob_start();
include_once("functions.php");
require_once  $_SERVER['DOCUMENT_ROOT']. '/vendor/autoload.php';

$info_arr = get_config();


/*pusher object */
$app_id = "584867";
$key = "37bcbe2616e8a051e236";
$secret = "5bc054588dd05ca9a8bf";
$options = array(
    'cluster' => 'eu',
    'encrypted' => true
);
$pusher = new Pusher\Pusher($key,$secret,$app_id,$options);


$success = false;
$captcha=$_POST['g-recaptcha-response'];

//check recaptcha is set and fine
if($captcha){
    if(isset($_POST['email']) && isset($_POST['message']) && isset($_POST['mobile']) ) {

//    error_reporting(E_ALL);
//    ini_set("display_errors", 1);

        $name = $_POST['name'];
        $email = $_POST['email'];
        $message = $_POST['message'];
        $mobile = $_POST['mobile'];


        $sql = $dbh->prepare("INSERT INTO enquiries (name, email,message,mobile, date_added) VALUES (:_name, :_email,:_message,:_mobile, NOW())");
        $sql->bindParam(":_name", $name, pdo::PARAM_STR);
        $sql->bindParam(":_email", $email, pdo::PARAM_STR);
        $sql->bindParam(":_message", $message, pdo::PARAM_STR);
        $sql->bindParam(":_mobile", $mobile, pdo::PARAM_STR);
        $sql->execute();

        $data['message'] =  $_POST['name'];
        $pusher->trigger('notifications','new_enquiry',$data['message']);



        $to = "feri_beni@yahoo.com";
        $subject = "New Enquiry";

        $message = nl2br($_POST['message']);
        $body = <<<HTML

           Name:{$_POST['name']}</br>
           Email: {$_POST['email']}</br>
           Mobile: {$_POST['mobile']}</br>
           Message: {$message}
           
HTML;

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
        $headers .= 'From: fazbenipt@gmail.com' . "\r\n";
        mail($to, $subject, $body, $headers);

        header("location: /contact?formsubmit=1");
        die();
    }
}else{
    //    header("location: /contact?formsubmit=1");



}







?>


<div id="fh5co-contact">

    <?php
    if(isset($_GET['formsubmit'])){
        echo "<h2 style='text-align: center;background: #36d33f;'>Message Sent, Will be in touch shortly!</h2>";
    }?>

    <div class="container">
        <form action="/includes/contact_form.php" method="POST">
            <div class="row">
                <div class="col-md-6 animate-box">
                    <h3 class="section-title">My Address</h3>
                    <p>info here</p>
                    <ul class="contact-info">
                        <li><i class="icon-location-pin"></i><?= $info_arr->address;?></li>
                        <li><i class="icon-phone2"></i><?= $info_arr->mobile;?></li>
                        <li><i class="icon-mail"></i><a href="mailto:<?=$info_arr->email;?>?Subject=Enquiry%20Session"><?= $info_arr->email;?></a></li>
                        <li><i class="icon-globe2"></i><a href="<?=$info_arr->website;?>"><?=$info_arr->website;?></a></li>
                    </ul>
                </div>
                <div class="col-md-6 animate-box">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Name" name="name" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Email" name="email" required>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Mobile" name="mobile" required>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <textarea name="message" class="form-control" id="" cols="30" rows="7" placeholder="Message" required></textarea>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <div class="g-recaptcha" data-sitekey="6LfM144UAAAAANd8hpe6sGZPOac_eJ5XZWPO4yUY"></div>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="submit" value="Send Message" class="btn btn-primary">
                            </div>
                        </div>




                    </div>
                </div>
            </div>
        </form>
    </div>
</div>


<script type="text/javascript">

    var checkCaatcha = grecaptcha.getResponse();

    if(checkCaatcha.length){

    }else{
        alert("Please select re-captcha!");
    }


    </script>



