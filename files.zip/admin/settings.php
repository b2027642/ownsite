<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 29/04/2018
 * Time: 13:23
 */
?>




<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 29/04/2018
 * Time: 11:33
 */?>

<?php include("includes/admin_header.php");?>
<body>

<div id="wrapper">



    <?php include("includes/admin_nav.php");?>


    <div id="page-wrapper">

        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="row">
                <div class="col-lg-12">


                    <h1 class="page-header">
                        Welcome to Comments Panel
                        <small>Author</small>
                    </h1>

                    <?php

                    $source= "";
                    if(isset($_GET['source'])){
                        $source = $_GET['source'];
                    }

                    switch($source){


                        case "edit_config";
                            include "includes/edit_config.php";
                            break;

                        default:
                            include("includes/settings.php");
                            break;

                    }//End Switch Case


                    ?>




                </div>
            </div>
            <!-- /.row -->

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->

    <?php include("includes/admin_footer.php");?>










