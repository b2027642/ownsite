
<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 30/12/2017
 * Time: 13:32
 */
include"admin_footer.php";
include "connection.php";
?>





<table class="table table-bordered table-hover">
    <thead>
    <tr>
        <th>ID</th>
        <th>email</th>
        <th>address</th>
        <th>Instagram</th>
        <th>mobile</th>
        <th>about</th>
        <th>Website</th>
        <th>Date Edited</th>
        <th>Edit</th>
    </tr>
    </thead>

    <tbody>

    <?php
    global $dbh;

    $config = $dbh->prepare("SELECT * FROM config ORDER BY id DESC");

    $config->execute();

    while($row = $config->fetch(PDO::FETCH_ASSOC)){

        $id = $row['id'];
        $about = substr($row['about'], 0,100) ;
        $email = $row['email'];
        $mobile = $row['mobile'];
        $address = $row['address'];
        $insta = $row['instagram'];
        $website= $row['website'];
        $date_edited=  date("d M D Y H:s", strtotime($row['date_edited']));

        echo <<<HTML
                        <tr>
                            <td>{$id}</td>
                            <td>{$email}</td>
                            <td>{$address}</td>
                            <td>{$insta}</td>
                            <td>{$mobile}</td>
                            <td>{$about}</td>
                            <td>{$website}</td>
                            <td>{$date_edited}</td>
                            <td><a href="settings.php?source=edit_config&config_id={$id}"><i class="fa fa-fw fa-edit"></i></a></td>
                        </tr>

HTML;
    }





    ?>

    </tbody>
</table>









