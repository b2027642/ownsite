<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 30/12/2017
 * Time: 13:32
 */
 include"admin_footer.php";
 include "connection.php";
?>





<table class="table table-bordered table-hover" name="tbl-contact" id="tbl-contact">
    <thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Mobile</th>
        <th>Message</th>
        <th>Date Added</th>
        <th>Contacted</th>
        <th>Delete</th>
    </tr>
    </thead>

    <tbody>

    <?php
    global $dbh;

    $get_enquiries = $dbh->prepare("SELECT * FROM enquiries ORDER BY id DESC");

    $get_enquiries->execute();

    while($row = $get_enquiries->fetch(PDO::FETCH_ASSOC)){

        $id = $row['id'];
        $name = $row['name'];
        $message = substr($row['message'], 0,100) ;
        $email = $row['email'];
        $mobile = $row['mobile'];
        $date = date("d/m/Y H:i" ,strtotime($row['date_added']));
        $contacted = $row['contacted'];
        if($contacted == "Yes"){
            $checked = "checked";
        }else{
            $checked = "";
        }

        echo <<<HTML
                        <tr>
                            <td>{$id}</td>
                            <td>{$name}</td>
                            <td>{$email}</td>
                            <td>{$mobile}</td>
                            <td>{$message}</td>
                            <td>{$date}</td>
                            <td><input type="checkbox" name="contacted"  id="{$id}" class="contact" value="Yes" $checked></td>
                            <td><a href="enquiries.php?delete={$id}"><i class="fa fa-fw fa-trash"></i></a></td>
                        </tr>

HTML;
    }





    ?>

    </tbody>
</table>


<?php
if(isset($_GET['delete'])){

    $enquiry_id  = $_GET['delete'];

    $delete_sql = $dbh->prepare("DELETE FROM enquiries WHERE  id = :_id");
    $delete_sql->bindParam(":_id", $enquiry_id, PDO::PARAM_INT);
    $delete_sql->execute();
    header("location: enquiries.php");
    die();


}
if(isset($_POST['id']) && isset($_POST['contacted']) ){

    $enq_id = $_POST['id'];
    $conatcted = $_POST['contacted'];


    $update_enq = $dbh->prepare("UPDATE enquiries SET contacted = :_contact WHERE id =:_id");
    $update_enq->bindParam(":_contact",$conatcted, PDO::PARAM_STR);
    $update_enq->bindParam(":_id",$enq_id, PDO::PARAM_INT);
    $update_enq->execute();
    header("location: enquiries.php");


}


?>




<script>


    $('.contact').click(function(){

        var contacted = $(this).val();
        var id = $(this).attr("id");

        if(this.checked){

            contacted = "Yes"
        }else{
            contacted = "No"
        }
        var dataString = {contacted:contacted,id:id}

        $.ajax({
        type: "POST",
        url: "fitness/admin/includes/view_all_enquiries.php",
        data: dataString,
        success: function (){
            alert("updated for you!");
        }

        });

    });


</script>


