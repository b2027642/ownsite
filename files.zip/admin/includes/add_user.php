

<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 28/12/2017
 * Time: 19:10
 */


global $dbh;

if(isset($_POST['add_user'])){


    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $password_hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
    //image variable
    $image = $_FILES['image']['name'];
    $image_temp = $_FILES['image']['tmp_name'];


    //uploading image to designated place
    move_uploaded_file($image_temp, "../images/$image");



    $user_insert = $dbh->prepare("INSERT INTO admin (email, password, confirm_password, hash_password, image, date_added)
                VALUES (:_email, :_password, :_confirm_password,:_hash_pass, :_img,   NOW() )");

    $user_insert->bindParam(":_email", $email, PDO::PARAM_STR );
    $user_insert->bindParam(":_password", $password, PDO::PARAM_STR );
    $user_insert->bindParam(":_confirm_password", $confirm_password, PDO::PARAM_STR );
    $user_insert->bindParam(":_hash_pass", $password_hash  , PDO::PARAM_STR );
    $user_insert->bindParam(":_img",$image, PDO::PARAM_STR );
    $user_insert->execute();

    echo "<span class='bg-success'>User Created:</span> " . " " . "<a href='users.php'> View Users</a>";
//    header("location: users.php");


}


?>




<form action="" method="post" enctype="multipart/form-data">



    <div class="form-group">
        <label for="user_email">Email</label>
        <input type="text" class="form-control" name="email">
    </div>

    <div class="form-group">
        <label for="user_password">Password</label>
        <input type="password" class="form-control" name="password">
    </div>
    <div class="form-group">
        <label for="user_password">Confirm Password</label>
        <input type="password" class="form-control" name="confirm_password">
    </div>


    <div class="form-group">
        <label for="image">Profile Image</label>
        <input type="file" name="image">
    </div>





    <div class="form-group">
        <input type="submit" class="btn btn-primary" value="Add user" name="add_user">

    </div>





</form>











