<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 28/12/2017
 * Time: 19:02
 */
global $dbh;

?>

<table class="table table-bordered table-hover">
    <thead>
    <tr>
        <th>ID</th>
        <th>Author</th>
        <th>Title</th>
        <th>Category</th>
        <th>Status</th>
        <th>Image</th>
        <th>Tags</th>
        <th>Comments</th>
        <th>Comments Count</th>
        <th>Date</th>
        <th>Edit</th>
        <th>Delete</th>
    </tr>
    </thead>

    <tbody>

    <?php

    $get_cat = $dbh->prepare("SELECT posts.*, categories.category_title
     From posts
                                                           LEFT JOIN categories
                                                           ON posts.category_id = categories.id
                                                           ORDER by posts.id DESC ");

    $get_cat->execute();

    while($row = $get_cat->fetch(PDO::FETCH_ASSOC)){

        $id = $row['id'];
        $author = $row['post_author'];
        $title = $row['post_title'];
        $date = date("d/m/Y H:i" ,strtotime($row['post_date']));
        $image = $row['post_image'];
        $comment = substr($row['post_content'], 0,100) ;
        $tags= $row['post_tags'];
        $status = $row['post_status'];
        $cat_name = $row['category_title'];
        $post_comment_count = $row['post_comment_counts'];

        //checking if the status is 1 or 0 and outputting the value
        if($status == 1){
            $status = "Active";
        }else{
            $status = "Disabled";
        }
        echo <<<HTML

                        <tr>
                            <td>{$id}</td>
                            <td>{$author}</td>
                            <td>{$title}</td>
                            <td>{$cat_name}</td>
                            <td>{$status}</td>
                            <td><img src="../images/{$image}" alt="image" width="120" height="50"></td>
                            <td>{$tags}</td>
                            <td>{$comment}</td>
                            <td>{$post_comment_count}</td>
                            <td>{$date}</td>
                            <td><a href="posts.php?source=edit_post&p_id={$id}"><i class="fa fa-fw fa-edit"></i></a></td>
                            <td><a href="posts.php?delete={$id}"><i class="fa fa-fw fa-trash"></i></a></td>
                        </tr>

HTML;
    }



    ?>

    </tbody>
</table>


<?php
    if(isset($_GET['delete'])){


        $post_id = $_GET['delete'];

        $delete_sql = $dbh->prepare("DELETE FROM posts WHERE  id = :_id");
        $delete_sql->bindParam(":_id", $post_id, PDO::PARAM_INT);
        $delete_sql->execute();
        header("location: posts.php");


    }

?>