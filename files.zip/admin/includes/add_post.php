<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 28/12/2017
 * Time: 19:10
 */
global $dbh;

if(isset($_POST['submit'])){

    $title = $_POST['post_title'];
    $author = $_POST['post_author'];
    $status = $_POST['post_status'];
    $tags = $_POST['post_tags'];
    $category = $_POST['category'];
    $content = $_POST['post_content'];
    //image variable
    $image = $_FILES['image']['name'];
    $image_temp = $_FILES['image']['tmp_name'];

    //uploading image to designated place
    move_uploaded_file($image_temp, "../images/$image");

    $cat_insert = $dbh->prepare("INSERT INTO posts (category_id,
                                                                post_author,
                                                                post_title,
                                                                post_image,
                                                                post_content,
                                                                post_tags,
                                                                post_comment_counts,
                                                                post_status,
                                                                post_date) VALUES (:_cat_id, :_author, :_title,  :_image, :_content, :_tags, 0, :_status, NOW() )");
    $cat_insert->bindParam(":_cat_id", $category, PDO::PARAM_INT);
    $cat_insert->bindParam(":_author", $author, PDO::PARAM_STR);
    $cat_insert->bindParam(":_title", $title, PDO::PARAM_STR);
    $cat_insert->bindParam(":_image", $image, PDO::PARAM_STR);
    $cat_insert->bindParam(":_content", $content, PDO::PARAM_STR);
    $cat_insert->bindParam(":_tags", $tags, PDO::PARAM_STR);
    $cat_insert->bindParam(":_status", $status, PDO::PARAM_STR);

    $cat_insert->execute();





}


?>




<form action="" method="post" enctype="multipart/form-data">

    <div class="form-group">
        <label for="title">Post Title</label>
        <input type="text" class="form-control" name="post_title">
    </div>

    <div class="form-group">
        <label for="author">Post Author</label>
        <input type="text" class="form-control" name="post_author">
    </div>

    <div class="form-group">
        <label for="status">Post Status</label>
        <select class="form-control" name="post_status">
            <option value="1">Active</option>
            <option value="0">Disabled</option>
        </select>

    </div>

    <div class="form-group">
        <label for="post_image">Post Image</label>
        <input type="file" name="image">
    </div>

    <div class="form-group">
        <label for="post_tags">Post TAGS</label>
        <input type="text" class="form-control" name="post_tags">
    </div>

    <div class="form-group">
        <label for="post_category">Post category</label>
        <select name="category" class="form-control">
            <option value="">Select Category</option>
            <?php
            $cat_sql = $dbh->prepare("SELECT * from categories");
            $cat_sql->execute();

            while($row = $cat_sql->fetch(PDO::FETCH_OBJ)){
                $id = $row->id;
                $cat_title = $row->category_title;
                echo"<option value='{$id}' >{$cat_title}</optio>";
            }
            ?>
        </select>
    </div>



    <div class="form-group">
        <label for="post_content"> POST Content</label>
        <textarea name="post_content" class="form-control" cols="30" id="body" rows="10"></textarea>
    </div>

    <div class="form-group">
        <input type="submit" class="btn btn-primary" value="Add Post" name="submit">

    </div>



</form>


