<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 29/04/2018
 * Time: 13:37
 */
 include "connection.php";
?>

<?php

if(isset($_GET['config_id'])){

    $config_id = $_GET['config_id'];
}


    $sql = $dbh->prepare("Select * FROM config WHERE id = :_id");
    $sql->bindParam(":_id", $config_id, PDO::PARAM_INT );
    $sql->execute();

    while($row =  $sql->fetch(PDO::FETCH_OBJ)){

        $email = $row->email;
        $address = $row->address;
        $website = $row->website;
        $instagram = $row->instagram;
        $about = $row->about;
        $mobile = $row->mobile;

    }


    if(isset($_POST['update_config'])){


        $email_edit = $_POST['email'];
        $address_edit = $_POST['address'];
        $website_edit = $_POST['website'];
        $instagram_edit = $_POST['instagram'];
        $about_edit = $_POST['about'];
        $mobile_edit = $_POST['mobile'];


        $update_config = $dbh->prepare("UPDATE `config` SET   
                                                            `email`=:_email,
                                                            `address`=:_address,
                                                            `instagram`=:_instagram,
                                                            `mobile`=:_mobile,
                                                            `about`=:_about,
                                                            `website`=:_wbsite,
                                                            `date_edited`= NOW()
 WHERE  `id`=:_id");
        $update_config->bindParam(":_email", $email_edit, PDO::PARAM_STR);
        $update_config->bindParam(":_address", $address_edit, PDO::PARAM_STR);
        $update_config->bindParam(":_instagram", $instagram_edit, PDO::PARAM_STR);
        $update_config->bindParam(":_mobile", $mobile_edit, PDO::PARAM_STR);
        $update_config->bindParam(":_about", $about_edit, PDO::PARAM_STR);
        $update_config->bindParam(":_wbsite", $website_edit, PDO::PARAM_STR);
        $update_config->bindParam(":_id", $config_id, PDO::PARAM_INT);
        $update_config->execute();
        header("location:settings.php");



    }

?>

<form action="" method="post" enctype="multipart/form-data">



    <div class="form-group">
        <label for="user_email">Email</label>
        <input type="text" class="form-control" name="email" value="<?= $email ?>">
    </div>

    <div class="form-group">
        <label> Address</label><br/>
        <textarea name="address"><?=$address?></textarea>
    </div>

    <div class="form-group">
        <label for="user_email">Instagram</label>
        <input type="text" class="form-control" name="instagram" value="<?= $instagram ?>">
    </div>

    <div class="form-group">
        <label for="user_email">Mobile</label>
        <input type="text" class="form-control" name="mobile" value="<?= $mobile ?>">
    </div>

    <div class="form-group">
        <label> About</label><br/>
        <textarea name="about"><?= $about?></textarea>
    </div>

    <div class="form-group">
        <label for="user_email">Website</label>
        <input type="text" class="form-control" name="website" value="<?= $website ?>">
    </div>



    <div class="form-group">
        <input type="submit" class="btn btn-primary" value="Update" name="update_config">

    </div>


</form>




