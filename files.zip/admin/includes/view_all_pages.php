<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 28/12/2017
 * Time: 19:02
 */
global $dbh;

?>
    <div class="table-responsive">
    <table class="table table-bordered table-hover table-striped">
        <thead>
        <tr>
            <th>ID</th>
            <th>Page Name</th>
            <th>url</th>
            <th>Author Name</th>
            <th>Status</th>
            <th>Date Added</th>
            <th>Date Edited</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        </thead>

        <tbody>

        <?php

        $sql = $dbh->prepare("SELECT * FROM pages LIMIT 20; ");
        $sql->execute();

        while($row = $sql->fetch(PDO::FETCH_ASSOC)){

            $id = $row['id'];
            $page_name = $row['page'];
            $url = $row['url'];
            $author_name = $row['author'];
            $meta_title = $row['meta_title'];
            $date_added = date("d/m/Y H:i" ,strtotime($row['date_added']));
            $date_edited = date("d/m/Y H:i" ,strtotime($row['date_edited']));
            $status = $row['status'];

            //checking if the status is 1 or 0 and outputtin

            if($status == 1){
                $status = "Disabled";
            }else{
                $status = "Active";
            }
            echo <<<HTML

                        <tr>
                            <td>{$id}</td>
                            <td>{$page_name}</td>
                            <td>/{$url}</td>
                            <td>{$author_name}</td>
                            <td>{$status}</td>
                            <td>{$date_added}</td>
                            <td>{$date_edited}</td>
                            <td><a href="pages.php?source=edit_page&p_id={$id}"><i class="fa fa-fw fa-edit"></i></a></td>
                            <td><a href="pages.php?delete={$id}"><i class="fa fa-fw fa-trash"></i></a></td>
                        </tr>

HTML;
        }



        ?>

        </tbody>
    </table>

    </div>


<?php
if(isset($_GET['delete'])){


    $page_id = $_GET['delete'];

    $delete_sql = $dbh->prepare("DELETE FROM pages WHERE  id = :_id");
    $delete_sql->bindParam(":_id", $page_id, PDO::PARAM_INT);
    $delete_sql->execute();
    header("location: pages.php");


}

?>