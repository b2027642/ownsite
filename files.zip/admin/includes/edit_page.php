<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 29/12/2017
 * Time: 11:57
 */

?>


<?php

global  $dbh;

if(isset($_GET['p_id'])){
    $page_id = $_GET['p_id'];
}else{
    header("location:". $_SERVER['HTTP_REFERER']);
}

$sql = $dbh->prepare("SELECT * FROM pages where id=:_id");
$sql->bindParam(":_id", $page_id, PDO::PARAM_INT);
$sql->execute();

while($row = $sql->fetch(PDO::FETCH_ASSOC)) {

    $id = $row['id'];
    $page_name = $row['page'];
    $meta_title = $row['meta_title'];
    $date_edited = date("d/m/Y H:i", strtotime($row['date_edited']));
    $image = $row['image'];
    $content = $row['content'];
    $status = $row['status'];
    $meta_keyword = $row['keyword'];
    $meta_description = $row['description'];
    $url = $row['url'];
    $author = $row['author'];




    if(isset($_POST['update_page'])){


        $page_name = $_POST['page_name'];
        $page_author = $_SESSION['name'];
        $page_status = $_POST['page_status'];
        $meta_title = $_POST['meta_title'];
        $meta_description = $_POST['meta_description'];
        $meta_keyword = $_POST['meta_keyword'];
        $content = $_POST['body'];
        $status = $_POST['page_status'];

        $RandomAccountNumber = mt_rand(1, 99999);

        //image variable
        $image_page = $_FILES['image']['name'];
        $image_temp_post =$_FILES['image']['tmp_name'];

        if(!empty($image_page)){
            $image_page = $RandomAccountNumber."-".$_FILES['image']['name'];
        }


        //uploading image to designated place
        move_uploaded_file($image_temp_post, "../images/$image_page");


        if(empty($image_page)){

            $sql = $dbh->prepare("SELECT * FROM pages WHERE id = :_id");
            $sql->bindParam(":_id", $page_id, PDO::PARAM_INT);
            $sql->execute();

            while($row = $sql->fetch(PDO::FETCH_OBJ)){

                $image_page = $row->image;
            }
        }


        $update_page = $dbh->prepare("UPDATE pages SET 
                                                page = :_page,
                                                meta_title = :_meta_title,
                                                image= :_image,
                                                content= :_content,
                                                keyword= :_keyword,
                                                description= :_description,
                                                url =:_url,
                                                author =:_author,
                                                status = :_status,
                                                date_edited= NOW()
                                                WHERE id = :_page_id");
        $update_page->bindParam(":_page", $page_name, PDO::PARAM_INT);
        $update_page->bindParam(":_meta_title", $meta_title, PDO::PARAM_STR);
        $update_page->bindParam(":_image", $image_page, PDO::PARAM_STR );
        $update_page->bindParam(":_content",$content, PDO::PARAM_STR );
        $update_page->bindParam(":_keyword", $meta_keyword, PDO::PARAM_STR);
        $update_page->bindParam(":_description", $meta_description, PDO::PARAM_STR);
        $update_page->bindParam(":_url", $page_name, PDO::PARAM_STR);
        $update_page->bindParam(":_author", $page_author, PDO::PARAM_STR);
        $update_page->bindParam(":_status", $status, PDO::PARAM_INT);
        $update_page->bindParam(":_page_id", $page_id, PDO::PARAM_INT);
        $update_page->execute();
        header("location: pages.php");




    }



}

?>



<form action="" method="post" enctype="multipart/form-data">

    <div class="form-group">
        <label for="title">Page name</label>
        <input type="text" class="form-control" name="page_name" value="<?=$page_name;?>">
    </div>

    <div class="form-group">
        <label for="author">Page Author</label>
        <input type="text" class="form-control" name="page_author" value="<?= $author;?>" disabled>
    </div>

    <div class="form-group">
        <label for="status">Post Status</label>
        <select class="form-control" name="page_status">
            <option value="">Please select...</option>
            <option value="0" <?php echo  ($status == 0)? "selected": "";?>>Active</option>
            <option value="1" <?php echo ($status == 1)? "selected":"";?>>Disabled</option>
        </select>

    </div>
    <div class="form-group">
        <label for="status">Page Content</label>

        <textarea name="body" id="body" class="form-control" rows="10" cols="80">
        <?=$content;?>
        </textarea>
    </div>

    <div class="form-group">
        <label for="status">Meta Title</label>
        <textarea name="meta_title" id=""  class="form-control" rows="10" cols="40"><?=$meta_title;?></textarea>
    </div>
    <div class="form-group">
        <label for="status">Meta description</label>
        <textarea name="meta_description" id="" class="form-control" rows="10" cols="40"><?=$meta_description;?></textarea>
    </div>
    <div class="form-group">
        <label for="status">Meta Keyword <em>use comma to separate keywords</em></label>
        <textarea name="meta_keyword" id="" class="form-control" rows="10" cols="40"><?=$meta_keyword;?></textarea>
    </div


    <div class="form-group" style="margin-bottom: 20px">
        <label for="page_image">Post Image</label>
        <input type="file" name="image" class="form-control">
        <br/>
        <img src="../images/<?= $image;?>" width="30%" height="10%" style="margin-bottom: 20px">
    </div>





    <div class="form-group" style="margin-top: 20px;">
        <input type="submit" class="btn btn-primary" value="Update Post" name="update_page">

    </div>

</form>







    <script type="text/javascript">
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace( '#body' );
</script>


