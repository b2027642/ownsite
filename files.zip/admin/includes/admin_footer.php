<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 24/12/2017
 * Time: 19:40
 */

?>





</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

<!-- feather light -->
<script src="//cdn.rawgit.com/noelboss/featherlight/1.7.12/release/featherlight.min.js" type="text/javascript" charset="utf-8"></script>
<script src="js/cke.js" type="text/javascript"></script></body>

</html>