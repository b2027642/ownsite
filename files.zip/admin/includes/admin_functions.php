<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 01/06/2018
 * Time: 23:40
 */

include_once "connection.php";




function get_enquiry_count(){


    global $dbh;

    $count_enq = $dbh->query("SELECT COUNT(id) AS count FROM enquiries WHERE contacted is NULL");
    $count_enq->execute();
    $data = $count_enq->fetch(pdo::FETCH_OBJ);
    $total = $data->count;
    return $total;
}


?>