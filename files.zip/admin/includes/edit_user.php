<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 13/01/2018
 * Time: 13:58
 */

?>


<?php

    global $dbh;

    if(isset($_GET['user_id'])){

        $userID = $_GET['user_id'];

    }


        $sql = $dbh->prepare("SELECT * from admin where id= :_u_id");
        $sql->bindParam(":_u_id", $userID, PDO::PARAM_INT);
        $sql->execute();

        while($row = $sql->fetch(PDO::FETCH_OBJ)){

            $id = $row->id;
            $email = $row->email;
            $image = $row->image;
            $date = date("Y-m-d", strtotime($row->date_added));




        }

        if(isset($_POST['update_user'])){


            $edit_email = $_POST['email'];



            $edit_image = $_FILES['image']['name'];
            $edit_image_tmp = $_FILES['image']['tmp_name'];


            move_uploaded_file($edit_image_tmp, "../images/$edit_image");


            if(empty($edit_image)){

                $sql = $dbh->prepare("SELECT * FROM admin WHERE id = :_id");
                $sql->bindParam(":_id", $userID, PDO::PARAM_INT);
                $sql->execute();

                while($row = $sql->fetch(PDO::FETCH_OBJ)){

                    $edit_image = $row->image;
                }
            }


            $update_user = $dbh->prepare("UPDATE admin SET 
                                                                   email = :_email,
                                                                   image= :_image,
                                                                   date_edited= NOW() WHERE id = :_id ");


            $update_user->bindParam(":_email", $edit_email, PDO::PARAM_STR);;
            $update_user->bindParam(":_image", $edit_image, PDO::PARAM_STR);
            $update_user->bindParam(":_id",    $userID, PDO::PARAM_INT);
            $update_user->execute();
            header("location: users.php");



        }







?>








<form action="" method="post" enctype="multipart/form-data">



    <div class="form-group">
        <label for="user_email">Email</label>
        <input type="text" class="form-control" name="email" value=" <?= $email ?>">
    </div>

    <div class="form-group">
        <label for="user_email">Date</label>
        <input type="date"  id="datepicker" class="form-control" name="date" value="<?=$date;?>">
    </div>



    <div class="form-group">
        <label for="image">Profile Image</label>
        <input type="file" name="image">
        <br/>
        <img src="../images/<?= $image;?>" width="30%" height="10%">
    </div>






    <div class="form-group">
        <input type="submit" class="btn btn-primary" value="Update" name="update_user">

    </div>





</form>


