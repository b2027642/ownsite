<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 29/12/2017
 * Time: 11:57
 */

?>


<?php



if(isset($_GET['p_id'])){


$post_id = $_GET['p_id'];

}

$get_cat = $dbh->prepare("SELECT posts.*, categories.category_title From posts
                                                           LEFT JOIN categories
                                                           ON posts.category_id = categories.id
                                                           where posts.id = :_post_id
                                                           ORDER by posts.id DESC ");


$get_cat->bindParam(":_post_id", $post_id, PDO::PARAM_INT);
$get_cat->execute();

while($row = $get_cat->fetch(PDO::FETCH_ASSOC)) {

    $id = $row['id'];
    $author = $row['post_author'];
    $title = $row['title'];
    $date = date("d/m/Y H:i", strtotime($row['post_date']));
    $image = $row['post_image'];
    $comment = $row['content'];
    $tags = $row['post_tags'];
    $status = $row['post_status'];
    $cat_name = $row['category_title'];
    $post_comment_count = $row['post_comment_counts'];
    $cat_id = $row['category_id'];



    if(isset($_POST['update_post'])){


        $title_post = $_POST['post_title'];
        $author_post = $_POST['post_author'];
        $status_post = $_POST['post_status'];
        $tags_post = $_POST['post_tags'];
        $category_post = $_POST['category'];
        $content_post = $_POST['post_content'];


        //image variable
        $image_post = $_FILES['image']['name'];
        $image_temp_post = $_FILES['image']['tmp_name'];

        //uploading image to designated place
        move_uploaded_file($image_temp_post, "../images/$image_post");


        if(empty($image_post)){

            $sql = $dbh->prepare("SELECT * FROM posts WHERE id = :_id");
            $sql->bindParam(":_id", $post_id, PDO::PARAM_INT);
            $sql->execute();

            while($row = $sql->fetch(PDO::FETCH_OBJ)){

                $image_post = $row->post_image;
            }
        }


        $update_post = $dbh->prepare("UPDATE posts SET 
                                                category_id = :_cat_id,
                                                post_author = :_post_author,
                                                title= :_post_title,
                                                post_date= NOW(),
                                                post_image= :_image,
                                                post_content= :_content,
                                                post_tags =:_tags,
                                                post_status = :_status  WHERE id = :_post_id");
        $update_post->bindParam(":_cat_id", $category_post, PDO::PARAM_INT);
        $update_post->bindParam(":_post_author", $author_post, PDO::PARAM_STR);
        $update_post->bindParam(":_post_title", $title_post, PDO::PARAM_STR );
        $update_post->bindParam(":_image",$image_post, PDO::PARAM_STR );
        $update_post->bindParam(":_content", $content_post, PDO::PARAM_STR);
        $update_post->bindParam(":_tags", $tags_post, PDO::PARAM_STR);
        $update_post->bindParam(":_status", $status_post, PDO::PARAM_INT);
        $update_post->bindParam(":_post_id", $post_id, PDO::PARAM_INT);
        $update_post->execute();
        header("location: posts.php");




    }



}

?>



<form action="" method="post" enctype="multipart/form-data">

    <div class="form-group">
        <label for="title">Post Title</label>
        <input type="text" class="form-control" name="post_title" value="<?=$title;?>">
    </div>

    <div class="form-group">
        <label for="author">Post Author</label>
        <input type="text" class="form-control" name="post_author" value="<?= $author;?>">
    </div>

    <div class="form-group">
        <label for="status">Post Status</label>
        <select class="form-control" name="post_status">
            <?php


            if($status ==1){
                echo '<option value="1" selected > Active</option>';
                echo '<option value="0"  > Disabled</option>';
            }else{
                echo '<option value="1"  > Active</option>';
                echo '<option value="0" selected > Disabled</option>';
            }

            ?>


        </select>

    </div>

    <div class="form-group">
        <label for="post_image">Post Image</label>
        <input type="file" name="image">
        <br/>
        <img src="../images/<?= $image;?>" width="30%" height="10%">
    </div>

    <div class="form-group">
        <label for="post_tags">Post TAGS</label>
        <input type="text" class="form-control" name="post_tags" value="<?= $tags;?>">
    </div>

    <div class="form-group">
        <label for="post_category">Post category</label>
        <select name="category" class="form-control">
            <option value="">Select Category</option>
v            <?php
            $cat_sql = $dbh->prepare("SELECT * from categories");
            $cat_sql->execute();

            while($row = $cat_sql->fetch(PDO::FETCH_OBJ)){
                $id = $row->id;
                $cat_title = $row->category_title;

                if($id == $cat_id ){
                    echo"<option value='{$id}' Selected >{$cat_title}</optio>";

                }else{
                    echo"<option value='{$id}'  >{$cat_title}</optio>";
                }
            }
            ?>
        </select>
    </div>



    <div class="form-group">
        <label for="post_content"> POST Content</label>
        <textarea name="post_content" class="form-control" cols="30" rows="10" ><?= $comment;?></textarea>
    </div>

    <div class="form-group">
        <input type="submit" class="btn btn-primary" value="Update Post" name="update_post">

    </div>





</form>

