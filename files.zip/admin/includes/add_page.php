

<?php

global  $dbh;





    if(isset($_POST['add_page'])){


        $page_name = $_POST['page_name'];
        $page_author = $_SESSION['name'];
        $page_status = $_POST['page_status'];
        $meta_title = $_POST['meta_title'];
        $meta_description = $_POST['meta_description'];
        $meta_keyword = $_POST['meta_keyword'];
        $content = $_POST['body'];
        $status = $_POST['page_status'];

        $RandomAccountNumber = mt_rand(1, 99999);

        //image variable
        $image_page = $RandomAccountNumber."-".$_FILES['image']['name'];
        $image_temp_post =$_FILES['image']['tmp_name'];

        //uploading image to designated place
        move_uploaded_file($image_temp_post, "../images/$image_page");





        $add_page = $dbh->prepare("INSERT INTO pages (page, meta_title,image,content,keyword,description,url,author,status,date_added)
         VALUES(:_page,
                :_meta_title,
                :_image,
                :_content,
                :_keyword,
                :_description,
                :_url,
                :_author,
                :_status,
                NOW())");
        $add_page->bindParam(":_page", $page_name, PDO::PARAM_INT);
        $add_page->bindParam(":_meta_title", $meta_title, PDO::PARAM_STR);
        $add_page->bindParam(":_image", $image_page, PDO::PARAM_STR );
        $add_page->bindParam(":_content",$content, PDO::PARAM_STR );
        $add_page->bindParam(":_keyword", $meta_keyword, PDO::PARAM_STR);
        $add_page->bindParam(":_description", $meta_description, PDO::PARAM_STR);
        $add_page->bindParam(":_url", $page_name, PDO::PARAM_STR);
        $add_page->bindParam(":_author", $page_author, PDO::PARAM_STR);
        $add_page->bindParam(":_status", $status, PDO::PARAM_INT);
        $add_page->execute();
        header("location: pages.php");




    }





?>



<form action="" method="post" enctype="multipart/form-data">

    <div class="form-group">
        <label for="title">Page name</label>
        <input type="text" class="form-control" name="page_name" value="">
    </div>

    <div class="form-group">
        <label for="status">Post Status</label>
        <select class="form-control" name="page_status">
            <option value="">Please select...</option>
            <option value="0">Active</option>
            <option value="1">Disabled</option>
        </select>

    </div>
    <div class="form-group">
        <label for="status">Page Content</label>

        <textarea name="body" id="body" class="form-control" rows="10" cols="80">
        </textarea>
    </div>

    <div class="form-group">
        <label for="status">Meta Title</label>
        <textarea name="meta_title" id=""  class="form-control" rows="10" cols="40"></textarea>
    </div>
    <div class="form-group">
        <label for="status">Meta description</label>
        <textarea name="meta_description" id="" class="form-control" rows="10" cols="40"></textarea>
    </div>
    <div class="form-group">
        <label for="status">Meta Keyword <em>use comma to separate keywords</em></label>
        <textarea name="meta_keyword" id="" class="form-control" rows="10" cols="40"></textarea>
    </div


    <div class="form-group" style="margin-bottom: 20px">
        <label for="page_image">Post Image</label>
        <input type="file" name="image" class="form-control">
    </div>





    <div class="form-group" style="margin-top: 20px;">
        <input type="submit" class="btn btn-primary" value="Update Post" name="add_page">

    </div>

</form>







<script type="text/javascript">
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace( '#body' );
</script>


