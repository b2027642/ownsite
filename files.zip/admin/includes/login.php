<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 29/04/2018
 * Time: 20:03
 */

include_once("connection.php");



global $dbh;
session_start();


if(isset($_POST['login'])){

    $email = $_POST['email'];
    $password = $_POST['password'];

    $get_user = $dbh->prepare("SELECT * FROM admin WHERE  email = :email ");
    $get_user->bindParam(":email", $email, pdo::PARAM_STR);
    $get_user->execute();
    $userData = $get_user->fetch(PDO::FETCH_OBJ);
    $user_password = $userData->hash_password;

    //check to see password has match with the one in the database.
    if(password_verify($password,$user_password)){

        $_SESSION['user_id']    = $userData->id;
        $_SESSION['email']  = $userData->email;
        $_SESSION['name']  = $userData->name;

        header("Location: ../home.php");
    }else{

        header("Location: ../../index");
    }

}

?>