<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 29/04/2018
 * Time: 20:12
 */

session_destroy();
session_unset();
ob_flush();
header("location:/index.php");
die();

?>