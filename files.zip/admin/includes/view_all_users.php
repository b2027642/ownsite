<?php
/**
 * Created by PhpStorm.
 * User: ferib
 * Date: 30/12/2017
 * Time: 13:32
 */

?>





<table class="table table-bordered table-hover">
    <thead>
    <tr>
        <th>ID</th>
        <th>Profile Image</th>
        <th>Email</th>
        <th>Date Added</th>
        <th>Edit</th>
        <th>Delete</th>
    </tr>
    </thead>

    <tbody>

    <?php
    global $dbh;

    $get_users = $dbh->prepare("SELECT * FROM admin order by id ASC");
    $get_users->execute();

    while($row = $get_users->fetch(PDO::FETCH_ASSOC)){

        $user_id = $row['id'];
        $email = $row['email'];
        $date_added = date("d/m/Y H:i",strtotime($row['date_added']));
        $image= $row['image'];



        echo <<<HTML
                        <tr>
                            <td>{$user_id}</td>
                            <td><img src="../images/{$image}" style="width:150px;height: 100px;" /></td>
                            <td>{$email}</td>
                            <td>{$date_added}</td>
                            <td><a href="users.php?source=edit_user&user_id={$user_id}"><i class="fa fa-fw fa-edit"></i></a></td>
                            <td><a href="users.php?delete={$user_id}"><i class="fa fa-fw fa-trash"></i></a></td>
                        </tr>

HTML;
    }




    ?>

    <style>
        .t-yes{
            background: forestgreen;
            color: white;
            padding:2px 2px 6px 2px;
            text-align: center;


        }

        .t-no{
            background: #ffb34b;
            color: white;
            padding:2px 2px 6px 2px;
            text-align: center;

        }
    </style>

    </tbody>
</table>



<?php

    if(isset($_GET['delete'])){


        $userID = $_GET['delete'];

        $userDelete = $dbh->prepare("DELETE FROM users where id =:_user_id");
        $userDelete->bindParam(":_user_id", $userID, PDO::PARAM_INT);
        $userDelete->execute();
        header("Location: users.php");

    }


    if(isset($_GET['toggle_on'])){

        $user_id = $_GET['toggle_on'];

        $update_role = $dbh->prepare("UPDATE users SET user_role = 1 WHERE id =:_id");
        $update_role->bindParam(":_id", $user_id, pdo::PARAM_INT);
        $update_role->execute();
        header("location: users.php");

    }

if(isset($_GET['toggle_off'])){

    $user_id = $_GET['toggle_off'];

    $update_role = $dbh->prepare("UPDATE users SET user_role = 0 WHERE id =:_id");
    $update_role->bindParam(":_id", $user_id, pdo::PARAM_INT);
    $update_role->execute();
    header("location: users.php");

}

?>

